package Robos_Teste;
import java.awt.Color;

import robocode.*;

public class robo2 extends AdvancedRobot{
	boolean movendo;
	boolean girando;
	int turnDirection = 1;
	int turnGirando = 1;
	int countScan,count;
	double gunTurnAmt;
	
	boolean tomotiro = false;
	
	public void run() {
		// Set colors
		setBodyColor(Color.black);
		setGunColor(Color.black);
		setRadarColor(Color.black);
		setBulletColor(Color.orange);
		setScanColor (Color.black);
		

		
		setAdjustGunForRobotTurn(true); // Keep the gun still when we turn
		gunTurnAmt = 10; // Initialize gunTurn to 10

		// Loop forever
		while (true) {
			// turn the Gun (looks for enemy)
			turnGunRight(gunTurnAmt);
			// Keep track of how long we've been looking
			count++;
			// If we've haven't seen our target for 2 turns, look left
			if (count > 2) {
				gunTurnAmt = -10;
			}
			// If we still haven't seen our target for 5 turns, look right
			if (count > 5) {
				gunTurnAmt = 10;
			}
			// If we *still* haven't seen our target after 10 turns, find another target
			if (count > 11) {
				//trackName = null;
			}
		}
	}

	public void direcaoReversa() {
		if (movendo) {
			setBack(130);
			movendo = false;
		} else {
			setAhead(0);
			movendo = true;
		}
	}
		
	public void onScannedRobot(ScannedRobotEvent e) {
		if (e.getBearing() >= 0) {
			turnDirection = 1;
		} else {
			turnDirection = -1;
		}
		setAhead(e.getDistance() - 40);
		fire(1);
		
		if(e.getDistance() <= 150) {
			fire(2);
		}
		if(e.getDistance() <= 100) {
			fire(3);
		}
		if(e.getDistance() <= 50) {
			setAhead(e.getDistance() - 20);
			setBodyColor(Color.ORANGE);
			fire(10);
			fire(10);
		}
		scan();
	}
	
	//QUANDO ACERTA O TIRO
	public void onBulletHit(BulletHitEvent e) {
		setBodyColor(Color.green);
		ahead(300);
	}

	//QUANDO TOMA O TIRO
	public void onHitByBullet(HitByBulletEvent e) {
		setBodyColor(Color.red);
		setTurnRight(50);
//		setMaxVelocity(10);
//		ahead(300);
		direcaoReversa();
	}
	
	public void onStatus(StatusEvent e) {}

	public void onBulletHitBullet(BulletHitBulletEvent e) {
		setBodyColor(Color.YELLOW);
	}

	public void onBulletMissed(BulletMissedEvent e) {
		setBodyColor(Color.BLUE);
	}

	public void onDeath(DeathEvent e) {}

	public void onHitRobot(HitRobotEvent e) {
		if (e.isMyFault()) {
			direcaoReversa();
		}
	}

	public void onHitWall(HitWallEvent e) {
		direcaoReversa();
	}

	public void onRobotDeath(RobotDeathEvent e) {}

	public void onWin(WinEvent e) {}
	
}
