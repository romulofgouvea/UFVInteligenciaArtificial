package Robos_Teste;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.util.ArrayList;

import robocode.*;

public class roboFinal extends AdvancedRobot{
	boolean movendo;
	int retornaADirecao = 1,retornaADirecao2 = 1, round = 0,acao = 0,moveCanhao,count,estrategia = 0,roundLoad;
	double media = 0.0,maior;
	ArrayList<String> arrayDados = new ArrayList<String>();
	ArrayList<String> arrayLoadDados = new ArrayList<String>();
	
	String dados = "";
	
	public void run() {
		
		round = getRoundNum()+1;
		save("round.txt",round);
		
		load("round.txt",1);
		if(round > roundLoad) {
			save("round.txt",round);
			load("round.txt",0);
		}
		
		if(round == 1 || estrategia == 1) {
			acao = 1;
			this.estrategia = 1;
		}
		if(round == 2 || estrategia == 2){
			acao = 2;
			this.estrategia = 2;
			arrayLoadDados.add(estrategia+","+media);
			saveFim("estrategia2.txt", arrayLoadDados);
		}
		if(round == 3 || estrategia == 3){
			acao = 3;
			this.estrategia = 3;
			if(arrayLoadDados.size() > 0)
				saveFim("estrategia3.txt", arrayLoadDados);
		}
		
		/*
		arrayDados.add(loadReturn("estrategia2.txt", 0));
		arrayDados.add(loadReturn("estrategia3.txt", 0));
		arrayDados.add(loadReturn("estrategiaFinal.txt", 0));
		
		if(round > 3){
			
			if(arrayDados.size() > 0) {
				double soma = 0;
				int maior = 0,count = 1,val;
				for(String dado: arrayDados) {
					
					String data[] = dado.split(",");
        			if(Integer.valueOf(data[1]) > maior) {
        				maior = Integer.valueOf(data[1]);
        				count++;
        			}
        			soma = soma + Double.valueOf(data[1]);
					
				}
				if(count%3 == 0 ) {
					val = count;
				}
				media = soma/arrayDados.size();
				arrayDados.add(count+","+media);
				saveFim("estrategiaFinal.txt", arrayDados);
			}
			
		}
		*/
		
		
		
		switch(acao) {
			case 1:
				
				setBodyColor(Color.orange);
				setGunColor(Color.orange);
				setRadarColor(Color.orange);
				setBulletColor(Color.orange);
				setScanColor (Color.orange);
				
				break;
			case 2:
				
				setBodyColor(Color.black);
				setGunColor(Color.black);
				setRadarColor(Color.black);
				setBulletColor(Color.orange);
				setScanColor (Color.black);
				
				setAdjustGunForRobotTurn(true); 
				moveCanhao = 10; 
				
				break;
			case 3:
				
				  setBodyColor(Color.yellow);
				  setGunColor(Color.yellow);
				  setRadarColor(Color.yellow);
				  setBulletColor(Color.orange);
				  setScanColor(Color.yellow);
				
				break;
		}		

		while (true) {	
			
			switch(acao) {
				case 1:
					
					turnRight(5 * retornaADirecao);
					
					break;
				case 2:
					
					turnGunRight(moveCanhao);
					count++;
					
					if (count > 2) {
						moveCanhao = -10;
					}
					if (count > 5) {
						moveCanhao = 10;
					}
					
					break;
				case 3:
					
					 turnRadarRight(360);
				     ahead(100);
				     turnGunRight(360);
				     back(100);
					
					break;
			}	
			
		}
	}
	
	//-------------------------------------------------------------------------FUNCIONALIDADES-----------------------------------------------------------------------
	public void onScannedRobot(ScannedRobotEvent e) {
		
		switch(acao) {
			case 1:
				
				if (e.getBearing() >= 0) {
					retornaADirecao = 1;
				} else {
					retornaADirecao = -1;
				}
				if(e.getDistance() > 150) {
					fire(1);
					ahead(e.getDistance() - 40);
				}
				if(e.getDistance() <= 150) {
					fire(2);
					ahead(e.getDistance() - 40);
				}
				if(e.getDistance() <= 100) {
					fire(3);
				}
				scan();
				
				break;
			case 2:
				
				if (e.getBearing() >= 0) {
					retornaADirecao2 = 1;
				} else {
					retornaADirecao2 = -1;
				}
				setAhead(e.getDistance() - 40);
				fire(1);
				
				if(e.getDistance() <= 150) {
					fire(2);
				}
				if(e.getDistance() <= 100) {
					fire(3);
				}
				if(e.getDistance() <= 50) {
					setAhead(e.getDistance() - 20);
					fire(10);
					fire(10);
				}
				scan();
				
				break;
			case 3:
				
				 double max = 100;
			      if(e.getEnergy() < max){
			         max = e.getEnergy();
			         MirandoC(e.getBearing(), max, getEnergy());
			      }else if(e.getEnergy() >= max){
			         max = e.getEnergy();
			         MirandoC(e.getBearing(), max, getEnergy());
			      }else if(getOthers() == 1){
			         max = e.getEnergy();
			         MirandoC(e.getBearing(), max, getEnergy());
			      }
				
				break;
		}
	}
	
	//QUANDO ACERTA O TIRO
	public void onBulletHit(BulletHitEvent e) {
		
		switch(acao) {
			case 2:
				ahead(300);
				break;
		}
	}

	//QUANDO TOMA O TIRO
	public void onHitByBullet(HitByBulletEvent e) {
		switch(acao) {
			case 1:
				direcaoReversa();
				setTurnRight(50);
				break;
		}
	}
	
	public void onHitRobot(HitRobotEvent e) {
		
		switch(acao) {
			case 1:
				
				if (e.isMyFault()) {
					direcaoReversa();
				}
				
				break;
			case 2:
				
				if (e.isMyFault()) {
					direcaoReversa();
				}
				
				break;
			case 3:
				
				HeadShoot( e.getEnergy(),e.getBearing(), getEnergy());
				
				break;
		}
		
		
	}
	
	public void onBulletMissed(BulletMissedEvent e) {
		
		switch(acao) {
			case 1:
				
				direcaoReversa();
				setTurnRight(50);
				
				break;
			case 2:
				
				break;
			case 3:
				
				
				break;
		}
	}
	
	public void onHitWall(HitWallEvent e) {
	      turnLeft(90);
	      ahead(200);
	}
	
	public void onWin(WinEvent e) {	
		turnRight(72000);
	}
	
	//--------------------------------------------------------------------------------METODOS-------------------------------------------------------------------------------------
	
	public void direcaoReversa() {
		if (movendo) {
			setBack(130);
			movendo = false;
		} else {
			setAhead(130);
			movendo = true;
		}
	}

	public void HeadShoot(double energiaIni ,double PosIni, double myEnergy) {
	  double Deagle = (energiaIni / 4) + .1;
	  double Range = getHeading() + PosIni - getGunHeading();
	  if (!(Range > -180 && Range <= 180)) {
		 while (Range <= -180) {
		    	 Range += 360;
			 }
		 while (Range > 180) {
			 Range -= 360;
		     } 
	    
		 
	  }
	  turnGunRight(Range);
	  fire(Deagle);
       
   }
	
	public void MirandoC(double PosIni, double energiaIni, double myEnergy) {
       double Distancia = PosIni;
	   double Range = getHeading() + PosIni - getGunHeading();
	   double Deagle = (energiaIni / 4) + .1;
	   if (!(Range > -180 && Range <= 180)) {
	      while (Range <= -180) {
	    	  Range += 360;
		  }
		  while (Range > 180) {
			  Range -= 360;
		  }
	   }
	   turnGunRight(Range);
		
	   if (Distancia > 200 || Deagle < 15 || energiaIni > Deagle){
          fire(1);
       } else if (Distancia > 50 ) {
          fire(2);
       } else {
          fire(Deagle);
       }
   }
	
	public void save(String path, float valor) {
		PrintStream w = null;
		try {
				w = new PrintStream(new RobocodeFileOutputStream(getDataFile(path)));
			
				if(valor == 0) {
					w.println(this.estrategia+","+this.media);
				}else {
					w.println((int)valor);
				}
				
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
				w.flush();
				w.close();
		}
		
	}
	
	public void saveFim(String path, ArrayList<String> arrayD) {
		try {
			BufferedWriter buffWriter = new BufferedWriter( new OutputStreamWriter( new RobocodeFileOutputStream(getDataFile(path) ) ) );
			if(arrayD.size() > 0) {
				for (String s: arrayD){
					buffWriter.write (s);
	            	buffWriter.newLine();
	            }
			}        
			buffWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void load(String path,int valor){
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(getDataFile(path)));
			String line = reader.readLine();
		
			if(valor == 0) {
				int index = 0;
		        while (line != null) {
		        	line= reader.readLine();
		        	arrayLoadDados.add(index, line);
					index++;
		        }
		        double maior = 0;
		        int strategy = 0;
		        if(arrayLoadDados.size() > 0) {
		        	for (String s: arrayLoadDados){
		        		
		        		String data[] = s.split(",");
	        			if(Integer.valueOf(data[1]) > maior) {
	        				strategy = Integer.valueOf(data[0]);
	        				maior = Integer.valueOf(data[1]);
	        			}
	        			
		            }
		        }
		        this.estrategia = strategy;
		        this.maior = maior;
			}else {
				this.roundLoad = Integer.valueOf(line);
			}
	        
	        reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//save1("robo1.txt");
	}//load
	
	
public String loadReturn(String path,int valor){
	ArrayList<String> arrayDadosLocal = new ArrayList<String>();
	double media = 0.0;
    int strategy = 0;
		try {
			BufferedReader reader = new BufferedReader(new FileReader(getDataFile(path)));
			String line = reader.readLine();
			
			if(valor == 0) {
				int index = 0;
		        while (line != null) {
		        	line= reader.readLine();
		        	arrayDadosLocal.add(index, line);
					index++;
		        }
		        
		        if(arrayDadosLocal.size() > 0) {
		        	for (String s: arrayDadosLocal){
		        		
		        		String data[] = s.split(",");
	        			if(Integer.valueOf(data[1]) > maior) {
	        				strategy = Integer.valueOf(data[0]);
	        				media = Integer.valueOf(data[1]);
	        			}
	        			
		            }
		        }
		        this.estrategia = strategy;
		        this.media = media;
			}else {
				this.roundLoad = Integer.valueOf(line);
			}
	        
			
	        reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return (strategy+","+media);
	}//load

}






