package Robos_Teste;
import java.awt.Color;
import java.util.ArrayList;

import robocode.*;

public class robo5 extends AdvancedRobot{
	ArrayList<String> arrayDados = new ArrayList<String>();
	public robo5() {
		arrayDados = utils.lerArquivo("robo1.txt");
	}
	
	public void run() {
		setBodyColor(Color.orange);
		setGunColor(Color.orange);
		setRadarColor(Color.orange);
		setBulletColor(Color.orange);
		setScanColor (Color.orange);

		while (true) {
			turnRight(5);
		}
	}
	
	public void onScannedRobot(ScannedRobotEvent e) {
		
	}
	
	//QUANDO ACERTA O TIRO
	public void onBulletHit(BulletHitEvent e) {}

	//QUANDO TOMA O TIRO
	public void onHitByBullet(HitByBulletEvent e) {}
	
	public void onStatus(StatusEvent e) {}

	public void onBulletHitBullet(BulletHitBulletEvent e) {}

	public void onBulletMissed(BulletMissedEvent e) {}

	public void onDeath(DeathEvent e) {}

	public void onHitRobot(HitRobotEvent e) {}

	public void onHitWall(HitWallEvent e) {}

	public void onRobotDeath(RobotDeathEvent e) {}

	public void onWin(WinEvent e) {}
}
