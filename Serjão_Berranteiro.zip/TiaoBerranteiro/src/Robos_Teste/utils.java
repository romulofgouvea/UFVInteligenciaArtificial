package Robos_Teste;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class utils {

	//VARIAVEIS LOCAIS
	static ArrayList<String> arrayTeste = new ArrayList<String>();
	final static String dir = System.getProperty("user.dir");
	
	
	public static void gravaArquivo(String nome, ArrayList<String> Objeto){
		
		try {
			File caminho = new File(dir+"/"+nome);
			caminho.createNewFile ();
			FileWriter fileWriter = new FileWriter (caminho);
            BufferedWriter buffWriter = new BufferedWriter (fileWriter);
			
            for (String s: Objeto){
            	buffWriter.write (s);
            	buffWriter.newLine();
            }
            buffWriter.close ();
           
		} catch (IOException e) {
			e.printStackTrace();
		}

	}// 

	public static ArrayList<String> lerArquivo(String nome) {
		ArrayList<String> arrayTestePrint = new ArrayList<String>();
		File arquivo = new File(dir+"/"+nome);
		try {
			BufferedReader br = new BufferedReader(new FileReader(arquivo));
			int index = 0;
			while(br.ready()){
			   String linha = br.readLine();
			   System.out.println(linha);
			   arrayTestePrint.add(index, linha);
			   index++;
			}
			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return arrayTestePrint;
	}
}