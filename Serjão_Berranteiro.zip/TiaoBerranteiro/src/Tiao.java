import java.util.ArrayList;

import Robos_Teste.utils;

public class Tiao {
	
	static ArrayList<String> arrayDados = new ArrayList<String>();
	public static void main(String[] args) {
		//utils.lerArquivo("arquivo.txt");
		gravaRobo1();
		gravaRobo2();
		gravaRobo3();

	}
	
	private static void gravaRobo1() {
		//variaveis
		arrayDados.add("boolean movendo; int retornaADirecao = 1;");
		//public void run()
		arrayDados.add("setBodyColor(Color.orange);" + 
				" setGunColor(Color.orange);" + 
				" setRadarColor(Color.orange);" + 
				" setBulletColor(Color.orange);" + 
				" setScanColor (Color.orange);" + 
				" while (true) {" + 
				" turnRight(5 * retornaADirecao);" + 
				" }");
		
//		public void onScannedRobot(ScannedRobotEvent e)	
		arrayDados.add("if (e.getBearing() >= 0) {" + 
				" retornaADirecao = 1;" + 
				" } else {" + 
				" retornaADirecao = -1;" + 
				" }" + 
				" if(e.getDistance() > 150) {" + 
				" fire(1);" + 
				" ahead(e.getDistance() - 40);" + 
				" }" + 
				" if(e.getDistance() <= 150) {" + 
				" fire(2);" + 
				" ahead(e.getDistance() - 40);" + 
				" }" + 
				" if(e.getDistance() <= 100) {" + 
				" fire(3);" + 
				" }" + 
				" scan();");
//		public void onBulletHit(BulletHitEvent e)
		arrayDados.add("if (e.isMyFault()) {" + 
				" direcaoReversa();" + 
				" }");
//		public void onHitByBullet(HitByBulletEvent e)
		arrayDados.add("direcaoReversa();" + 
				" setTurnRight(50);");
//		public void onStatus(StatusEvent e)
		arrayDados.add("0");
//		public void onBulletHitBullet(BulletHitBulletEvent e)
		arrayDados.add("0");
//		public void onBulletMissed(BulletMissedEvent e)
		arrayDados.add("0");
//		public void onDeath(DeathEvent e) {}
		arrayDados.add("0");
//		public void onHitRobot(HitRobotEvent e)
		arrayDados.add("0");
//		public void onHitWall(HitWallEvent e) 
		arrayDados.add("0");
//		public void onRobotDeath(RobotDeathEvent e)
		arrayDados.add("0");
//		public void onWin(WinEvent e)
		arrayDados.add("0");
		
		//Metodos
		arrayDados.add("public void direcaoReversa() {" + 
				" if (movendo) {" + 
				" setBack(130);" + 
				" movendo = false;" + 
				" } else {" + 
				" setAhead(130);" + 
				" movendo = true;" + 
				" }" + 
				" }");
		
		//gravar fun��es do robo
		utils.gravaArquivo("robo1.txt",arrayDados);
	}
	
	private static void gravaRobo2() {
		arrayDados.clear();
		//variaveis
		arrayDados.add("");
		//public void run()
		arrayDados.add("");
//		public void onScannedRobot(ScannedRobotEvent e)	
		arrayDados.add("");
//		public void onBulletHit(BulletHitEvent e)
		arrayDados.add("");
//		public void onHitByBullet(HitByBulletEvent e)
		arrayDados.add("");
//		public void onStatus(StatusEvent e)
		arrayDados.add("");
//		public void onBulletHitBullet(BulletHitBulletEvent e)
		arrayDados.add("");
//		public void onBulletMissed(BulletMissedEvent e)
		arrayDados.add("");
//		public void onDeath(DeathEvent e) {}
		arrayDados.add("");
//		public void onHitRobot(HitRobotEvent e)
		arrayDados.add("");
//		public void onHitWall(HitWallEvent e) 
		arrayDados.add("");
//		public void onRobotDeath(RobotDeathEvent e)
		arrayDados.add("");
//		public void onWin(WinEvent e)
		arrayDados.add("");
		//gravar fun��es do robo
		utils.gravaArquivo("robo2.txt",arrayDados);
	}
	
	private static void gravaRobo3() {
		arrayDados.clear();
		
		//gravar fun��es do robo
		utils.gravaArquivo("robo3.txt",arrayDados);
	}
	
	
	
	

}
